from django.apps import AppConfig


class DatasetsCollationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datasets_collation'
